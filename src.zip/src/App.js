import './App.css';
// import About from './components/About';
import Navbar from './components/Navbar';
import TextForm from './components/TextForm';
function App() {
  return (
    <>
{/* <Navbar tittle="TextUtils" aboutText="About TextUtils"/> */}
<Navbar tittle="TextUtils"/>
<div className="container my-3">
<TextForm heading= "Enter the text to analyze below"/>
{/* <About/> */}
</div>
    </>

  );
}
export default App;

